import time
import random
import keyboard

# 模拟正常用户行为特征
normal_behavior = {
    "avg_key_press_speed": 150,  # 平均击键速度（毫秒）
    "error_rate": 0.05,  # 错误率
    "key_press_duration": {
        "min": 100,  # 最短按键时长（毫秒）
        "max": 250,  # 最长按键时长（毫秒）
    },
}

# 用户行为数据存储
user_behaviors = {}


def record_behavior(user_id, password):
    """记录用户输入行为数据"""
    start_time = time.time()
    key_press_times = []
    errors = 0

    # 使用 keyboard.write 模拟用户输入
    keyboard.write(password)

    # 计算按键时间
    for i, char in enumerate(password):
        key_press_times.append(time.time() - start_time)
        if random.random() < normal_behavior["error_rate"]:  # 模拟错误输入
            errors += 1
            print(f"输入错误，请重新输入第 {i + 1} 个字符")
            time.sleep(1)  # 模拟用户修正错误时间
            keyboard.write(char)
            key_press_times.append(time.time() - start_time)

    end_time = time.time()

    # 计算行为特征
    avg_key_press_speed = (end_time - start_time) / len(password) * 1000
    error_rate = errors / len(password)
    key_press_duration = {
        "min": min(key_press_times),
        "max": max(key_press_times),
    }

    # 存储用户行为数据
    user_behaviors[user_id] = {
        "avg_key_press_speed": avg_key_press_speed,
        "error_rate": error_rate,
        "key_press_duration": key_press_duration,
    }

    print(f"用户 {user_id} 的行为数据已记录：")
    print(user_behaviors[user_id])


def verify_behavior(user_id, password):
    """验证用户行为"""
    record_behavior(user_id, password)  # 记录用户当前行为

    # 获取用户行为数据
    user_behavior = user_behaviors[user_id]

    # 判断用户行为是否与正常行为特征匹配
    if (
        abs(user_behavior["avg_key_press_speed"] - normal_behavior["avg_key_press_speed"])
        <= 10
        and abs(user_behavior["error_rate"] - normal_behavior["error_rate"]) <= 0.01
        and user_behavior["key_press_duration"]["min"]
        >= normal_behavior["key_press_duration"]["min"] - 50
        and user_behavior["key_press_duration"]["max"]
        <= normal_behavior["key_press_duration"]["max"] + 50
    ):
        print("验证成功！")
    else:
        print("验证失败！")


if __name__ == "__main__":
    user_id = "user1"
    password = input("请输入密码：")
    verify_behavior(user_id, password)